'use client';

/**
 * EventsHero.tsx — Church Events hero with a looping YouTube background.
 *
 * Video:     YT_ID below (a YouTube Short, muted + looping)
 * Fallback:  POSTER image shows while the video loads, if autoplay is blocked,
 *            or if the visitor prefers reduced motion
 * Height:    min-h-[460px]  (change HERO_H class below if you want it taller)
 * Tint:      TINT = navy overlay strength (0.55 light ... 0.85 dark)
 */

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAppStore } from '@/lib/store';

const POSTER = 'https://i.pinimg.com/736x/93/65/5c/93655cbaa1f0c6da77af423e851c9004.jpg';
const YT_ID = 'uPty-Paq2E4';
const YT_SRC =
  `https://www.youtube-nocookie.com/embed/${YT_ID}` +
  `?autoplay=1&mute=1&loop=1&playlist=${YT_ID}` +
  `&controls=0&modestbranding=1&playsinline=1&rel=0&disablekb=1&iv_load_policy=3`;
const TINT = 0.65;

export function EventsHero() {
  const { locale } = useAppStore();
  const am = locale === 'am';

  const [still, setStill] = useState(false); // true = reduced motion -> no video

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setStill(mq.matches);
    const on = () => setStill(mq.matches);
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);

  return (
    <section
      aria-labelledby="page-title"
      className="relative flex min-h-[460px] items-center overflow-hidden bg-[#0b1a3f] bg-cover bg-center"
      style={{ backgroundImage: `url('${POSTER}')` }}
    >
      {/* Background video (Shorts are vertical 9:16: full width, cropped top/bottom) */}
      {!still && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
          <iframe
            src={YT_SRC}
            title="Church events background video"
            allow="autoplay; encrypted-media"
            tabIndex={-1}
            loading="lazy"
            className="absolute left-1/2 top-1/2 w-full -translate-x-1/2 -translate-y-1/2 border-0"
            style={{ aspectRatio: '9 / 16' }}
          />
        </div>
      )}

      {/* Navy tint (darker on the left so the title stays readable) */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background: `linear-gradient(90deg, rgba(9,18,38,${TINT + 0.27}) 0%, rgba(9,18,38,${TINT - 0.05}) 45%, rgba(9,18,38,${TINT - 0.4}) 100%), linear-gradient(0deg, rgba(9,18,38,0.55), transparent 40%)`,
        }}
      />

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-[1680px] px-5 pb-24 pt-16 sm:px-10 lg:px-20">
        <nav
          aria-label="Breadcrumb"
          className="mb-4 flex items-center gap-2.5 text-[13px] tracking-[0.08em] text-[#b4bfd9]"
        >
          <Link href="/" className="transition hover:text-[#e3c476]">
            {am ? 'መነሻ' : 'Home'}
          </Link>
          <span aria-hidden="true">/</span>
          <span aria-current="page" className="font-semibold text-[#e3c476]">
            {am ? 'ሁነቶች' : 'Events'}
          </span>
        </nav>

        <h1
          id="page-title"
          className="text-[46px] font-semibold leading-[0.95] tracking-[-0.03em] text-[#f6efdd] [text-shadow:0_3px_14px_rgba(0,0,0,.5)] sm:text-[72px] lg:text-[92px]"
          style={{ fontFamily: 'var(--serif, "Fraunces", Georgia, serif)' }}
        >
          {am ? (
            <>
              የቤተክርስቲያን <em className="text-[#e3c476]">ሁነቶች</em>
            </>
          ) : (
            <>
              Church <em className="text-[#e3c476]">Events</em>
            </>
          )}
        </h1>

        <p
          className="mt-4 text-[19px] italic text-[#cdd6ea] sm:text-[24px]"
          style={{ fontFamily: 'var(--serif, "Fraunces", Georgia, serif)' }}
        >
          {am ? 'ይሰብሰቡ። ያምልኩ። በአንድነት ያገልግሉ።' : 'Gather. Worship. Serve together.'}
        </p>
      </div>
    </section>
  );
}