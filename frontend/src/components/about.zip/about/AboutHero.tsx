'use client';

/**
 * AboutHero.tsx — Editorial hero on deep forest navy with glance stats card.
 * Exact layout from Tewahedo HTML design.
 */

import React, { useRef } from 'react';
import Link from 'next/link';
import { useAppStore } from '@/lib/store';
import { SplitWords } from '@/components/motion/SplitWords';
import { useHeroMotion } from './useAboutMotion';

export function AboutHero() {
  const { locale } = useAppStore();
  const am = locale === 'am';
  const root = useRef<HTMLDivElement>(null);
  useHeroMotion(root);

  return (
    <div ref={root}>
      <section className="about-hero">
        <div className="c">
          <svg className="pat" data-parallax viewBox="0 0 640 520" aria-hidden="true">
            <rect width="640" height="520" fill="url(#lat)" />
          </svg>
          <div className="hero-text">
            <nav aria-label="Breadcrumb" className="crumbs" data-a="crumbs">
              <Link href="/" className="hover:underline">
                {am ? 'መነሻ' : 'Home'}
              </Link>
              <span>/</span>
              <b>{am ? 'ስለ እኛ' : 'About'}</b>
            </nav>
            <h1>
              {am ? (
                <>
                  <SplitWords text="ስለ" /> <em><SplitWords text="እኛ" /></em>
                </>
              ) : (
                <>
                  <SplitWords text="About" /> <em><SplitWords text="Us" /></em>
                </>
              )}
            </h1>
            <p data-a="sub">
              {am
                ? 'እምነታችን። ተልዕኳችን። ማኅበረሰባችን።'
                : 'Our Faith. Our Mission. Our Community.'}
            </p>
          </div>
          <div className="glance" data-a="glance">
            <h4>{am ? 'በጨረፍታ' : 'At a glance'}</h4>
            <div className="row">
              <span>{am ? 'የተቋቋመው' : 'Serving since'}</span>
              <b>1998</b>
            </div>
            <div className="row">
              <span>{am ? 'የሰንበት ት/ቤት ተማሪዎች' : 'Sunday School students'}</span>
              <b>200+</b>
            </div>
            <div className="row">
              <span>{am ? 'ንቁ አገልግሎቶች' : 'Active ministries'}</span>
              <b>4</b>
            </div>
          </div>
        </div>
      </section>
      <div className="about-ribbon" aria-hidden="true" data-line />
    </div>
  );
}
